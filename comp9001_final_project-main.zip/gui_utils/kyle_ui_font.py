# Create a font dictionary
dky_fonts = {}

# List of fonts and their applicable systems and uses
font_info = [
    "Times New Roman",  # Windows, macOS, text
    "Microsoft YaHei",  # Windows, text and controls
    "SF Pro",  # macOS, text and controls
    "Roboto",  # Windows, macOS, text and controls
    "Helvetica",  # macOS, text and controls
    "Open Sans",  # Windows, macOS, text and controls
    "Avenir",  # macOS, text and controls
    "PingFang SC",  # macOS, text and controls
    "Source Han Sans",  # Windows, macOS, text and controls
    "Arial",  # Windows, macOS, text and controls
    "DIN",  # Windows, macOS, text and controls
    "Futura",  # Windows, macOS, text and controls
    "Garamond",  # Windows, macOS, text
    "Segoe UI Symbol"  # Symbol
]

# Use loops to create fonts from size 10 to 40
for font_name in font_info:
    for size in range(10, 51):
        # font_name = font_name.replace(' ', '_') # Replace spaces
        font_name_key = font_name.split(" ")[0]
        font_key = f"{font_name_key}_{size}"
        dky_fonts[font_key] = (font_name, size)  # Add to the dictionary
        # Add explanatory comments
        # print(f"# {font_key} usage")

# Example: Accessing a font
# print(dky_fonts["Times_25"])  # Output: ('Times New Roman', 25)

