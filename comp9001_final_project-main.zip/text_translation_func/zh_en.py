import os
import time
import torch
from transformers import MarianMTModel, MarianTokenizer

# Disable HuggingFace symbolic link warning
os.environ["HF_HUB_DISABLE_SYMLINKS_WARNING"] = "true"

# Mapping table of language pairs and models
LANGUAGE_MODEL_MAPPING = {
    "中文 ➜ 英文": "Helsinki-NLP/opus-mt-zh-en",
    "英文 ➜ 中文": "Helsinki-NLP/opus-mt-en-zh",
    "日文 ➜ 英文": "Helsinki-NLP/opus-mt-ja-en",
    "英文 ➜ 日文": "Helsinki-NLP/opus-mt-en-ja",
    "韩文 ➜ 英文": "Helsinki-NLP/opus-mt-ko-en",
    "英文 ➜ 韩文": "Helsinki-NLP/opus-mt-en-ko",
    "法文 ➜ 英文": "Helsinki-NLP/opus-mt-fr-en",
    "英文 ➜ 法文": "Helsinki-NLP/opus-mt-en-fr",
}


def translate_text_with_time(
        task: str, text: str, device_setting: str = "auto", precision_setting: str = "fp32"
):
    """
    Translate using the specified translation task and input text, and record stage times.

    Parameters:
    ------
    task : str
        Language pair for the translation task (e.g. "中文 ➜ 英文", "英文 ➜ 中文").
    text : str
        Input text to be translated.
    device_setting : str, optional
        Device type, default "auto" (supports "auto", "cpu", "cuda").
    precision_setting : str, optional
        Precision option, default "fp32" (supports "fp32", "fp16", "int8").

    Returns:
    -------
    tuple : (str, list)
        - str: Translated text result.
        - list: Array containing the time of each stage [tokenization time, translation time, decoding time].
    """
    '''
    Translates using the specified translation task and input text, and counts stage times.

    Parameters.
    ------
    task : str
        Language pair for the translation task (e.g. "Chinese ➜ English", "English ➜ Chinese").
    text : str
        Input text to be translated.
    device_setting : str, optional
        device_setting, default is "auto" (supports "auto", "cpu", "cuda").
    precision_setting : str, optional
        Precision options, default "fp32" (supports "fp32", "fp16", "int8").

    Return value.
    -------
    tuple : (str, list)
        - str: the result of the translated text.
        - list: an array containing the time of each stage [time spent on segmentation, time spent on translation, time spent on decoding].
    '''
    if task not in LANGUAGE_MODEL_MAPPING:
        raise ValueError(f"Unsupported translation task: {task}")

    model_name = LANGUAGE_MODEL_MAPPING[task]

    # Start model loading time
    model_load_start_time = time.time()

    # Determine device
    if device_setting == "auto":
        device = "cuda" if torch.cuda.is_available() else "cpu"
    else:
        device = device_setting
    print(f"Using device: {device}")

    # Load model and set precision
    if precision_setting == "fp16" and device == "cuda":
        model = MarianMTModel.from_pretrained(model_name, torch_dtype=torch.float16)
    elif precision_setting == "int8" and device == "cuda":
        from transformers import BitsAndBytesConfig
        quantization_config = BitsAndBytesConfig(load_in_8bit=True)
        model = MarianMTModel.from_pretrained(model_name, quantization_config=quantization_config, device_map="auto")
    else:
        model = MarianMTModel.from_pretrained(model_name)  # Default fp32
    model = model.to(device)
    tokenizer = MarianTokenizer.from_pretrained(model_name)

    # Model loading complete time
    model_load_end_time = time.time()
    print(f"Model loaded, time taken: {model_load_end_time - model_load_start_time:.4f} seconds")

    # Start timing for each translation stage
    # 1. Tokenization and input preparation
    stage1_start_time = time.time()
    inputs = tokenizer([text], return_tensors="pt", padding=True).to(device)
    stage1_end_time = time.time()

    # 2. Translation generation
    stage2_start_time = time.time()
    translated = model.generate(**inputs)
    stage2_end_time = time.time()

    # 3. Decode translation result
    stage3_start_time = time.time()
    translated_text = tokenizer.decode(translated[0], skip_special_tokens=True)
    stage3_end_time = time.time()

    # Calculate time array
    time_stats = [
        stage1_end_time - stage1_start_time,  # Tokenization and input preparation time
        stage2_end_time - stage2_start_time,  # Translation generation time
        stage3_end_time - stage3_start_time,  # Decoding translation result time
    ]

    return translated_text, time_stats


def load_model(model_name,device_setting:str="auto",precision_setting:str="fp32"):

    # Start model loading time
    model_load_start_time = time.time()

    # Determine device
    if device_setting == "auto":
        device = "cuda" if torch.cuda.is_available() else "cpu"
    else:
        device = device_setting
    print(f"Using device: {device}")

    # Load model and set precision
    if precision_setting == "fp16" and device == "cuda":
        model = MarianMTModel.from_pretrained(model_name, torch_dtype=torch.float16)
    elif precision_setting == "int8" and device == "cuda":
        from transformers import BitsAndBytesConfig
        quantization_config = BitsAndBytesConfig(load_in_8bit=True)
        model = MarianMTModel.from_pretrained(model_name, quantization_config=quantization_config, device_map="auto")
    else:
        model = MarianMTModel.from_pretrained(model_name)  # Default fp32
    model = model.to(device)
    tokenizer = MarianTokenizer.from_pretrained(model_name)

    # Model loading complete time
    model_load_end_time = time.time()
    print(f"Model loaded, time taken: {model_load_end_time - model_load_start_time:.4f} seconds")

    return  model, tokenizer, device

def translate_text(model, tokenizer, device, text):
    # max_length: Limit the maximum number of tokens generated.
    # early_stopping = True: Stop immediately at EOS.
    # num_beams: Use search to improve translation quality.
    # no_repeat_ngram_size: Prohibit repeated n-grams.
    # repetition_penalty: Penalize repeated words to reduce their probability.

#     # 1. Tokenize and send to device
#     inputs = tokenizer(
#         [text],
#         return_tensors="pt",
#         padding=True,
#         truncation=True,
#         max_length=128
#     ).to(device)
#
#     # 2. Add generation control parameters
#     translated = model.generate(
#         **inputs,
#         max_length=50,             # Up to 50 tokens
#         early_stopping=True,       # Stop at EOS
#         num_beams=4,               # 4-way beam search
#         no_repeat_ngram_size=2,    # Prohibit 2-gram repetition
#         repetition_penalty=1.2,    # Repetition penalty
#     )
#
    inputs = tokenizer([text], return_tensors="pt", padding=True,truncation=True,max_length=128).to(device)
    # translated = model.generate(**inputs)
    translated = model.generate(
        **inputs,
        max_length=50,             # Up to 50 tokens
        early_stopping=True,       # Stop at EOS
        num_beams=4,               # 4-way beam search
        no_repeat_ngram_size=2,    # Prohibit 2-gram repetition
        repetition_penalty=1.2,    # Repetition penalty
    )

    translated_text = tokenizer.decode(translated[0], skip_special_tokens=True)
    return translated_text


def start_trans_ZHtoEN(text: list[str]):
    model, tokenizer, device = load_model("Helsinki-NLP/opus-mt-zh-en") # = "中文 ➜ 英文"  # You can try switching to other language pairs, such as "英文 ➜ 中文"
    results = []
    for i in text:
        if i:
            reuslt = translate_text(model, tokenizer, device,i)
            print(reuslt)
            results.append(reuslt)
    return results

def start_trans_ENtoZH(text: list[str]):
    model, tokenizer, device = load_model("Helsinki-NLP/opus-mt-en-zh") # = "中文 ➜ 英文"  # You can try switching to other language pairs, such as "英文 ➜ 中文"
    results =[]
    for i in text:
        if i:
            reuslt = translate_text(model, tokenizer, device,i)
            print(reuslt)
            results.append(reuslt)
    return results


def test1():
    # Input parameters
    task = "中文 ➜ 英文"  # You can try switching to other language pairs, such as "英文 ➜ 中文"
    text = "我们可以通过 HuggingFace 提供的工具高效完成翻译任务。"
    device_setting = "auto"  # Options: "cpu", "cuda", "auto"
    precision_setting = "fp16"  # Options: "fp32", "fp16", "int8"

    # Execute translation task
    try:
        translated_text, time_stats = translate_text_with_time(
            task=task,
            text=text,
            device_setting=device_setting,
            precision_setting=precision_setting,
        )
        # Output translation result and stage time
        print(f"\n【{task}】\nTranslation result: {translated_text}")
        print("Stage time statistics:")
        print(f"1. Tokenization time: {time_stats[0]:.4f} seconds")
        print(f"2. Translation time: {time_stats[1]:.4f} seconds")
        print(f"3. Decoding time: {time_stats[2]:.4f} seconds")
        print(f"Total translation time: {sum(time_stats):.4f} seconds")

    except ValueError as e:
        print(str(e))


# ==== Example call ====
if __name__ == "__main__":
   text=["你好","世界","黄河之水天上来，奔流到海不复回"]
   # zh_results = start_trans_ZHtoEN(text)
   # print(zh_results)
   # print("\n\nxxxxxxxxxx\n\n\n")
   en_results = start_trans_ENtoZH(['Hello', 'World', 'The waters of the Yellow River come up and run to the sea.'])
   print(en_results)
