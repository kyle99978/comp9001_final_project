The program is designed based on win11+python3.12

You can use the functions by running main.py

Currently available functions:
Text translation window, 
MP3 audio file transcription, 
AI chat window

# You can play the demo video to check how to use this application.
### As used APIs, you should complete your own API KEY in the code to ensure that codes work. Please read the README files in all subdirectories if you want to master it fully.



##########################################################################################################

# DUAN_Translating: Your All-in-One AI Language Assistant

Powered by cutting-edge AI models (ChatGPT & DeepSeek), state-of-the-art audio processing (Whisper), and world-class translation APIs (DeepL & Google), DUAN_Translating is a comprehensive tool that combines text translation, audio transcription/translation, and document editing into a single intelligent platform.

Whether you're working on cross-language writing, generating subtitles for audio/video, transcribing meetings, or simply translating everyday content, DUAN_Translating delivers fast, accurate, and natural language services.

🔹 Supports multilingual transcription & translation

🔹 Built-in speech recognition engine with input from PC software, microphone, audio, and video files (currently optimized for audio)

🔹 Seamless switching between intelligent models, fully compatible with GPT and DeepSeek families

🔹 Light and dark themes for a comfortable experience, day or night

🔹 Offline editing and multi-format export to easily save and organize your translated content


Designed for creators, researchers, content producers, and multilingual users alike, DUAN_Translating is your all-in-one language toolkit.

Break the boundaries of language—start using DUAN_Translating today.




