https://huggingface.co/models?sort=downloads&search=opus-mt

#Chinese (zh) 
#English (en)  
#Japanese (ja) 
#Korean (ko) 
#German (de)  
#French (fr)
#Russian (ru)
#Arabic (ar)
#Spanish (es)
#Portuguese (pt)
#Vietnamese (vi)
#Thai (th)
#Indonesian (id)



#中文（zh）
#英文（en）
#日语（ja）
#韩语（ko）
#德语（de）
#法语（fr）
#俄语（ru）
#阿拉伯语（ar）
#西班牙语（es）
#葡萄牙语（pt）
#越南语（vi）
#泰语（th）
#印尼语（id）