# import tkinter as tk
# import time
# import os
#
# def reset_buttons():
#     b_start.config(state=tk.NORMAL)
#     b_pause.config(state=tk.DISABLED)
#     b_resume.config(state=tk.DISABLED)
#     b_end.config(state=tk.DISABLED)
#
# def reset_timer():
#     global timer_running, start_time, paused_time
#     timer_running = False
#     start_time = 0
#     paused_time = 0
#     label_time.config(text="00:00:00")
#
# def on_start():
#     global timer_running, start_time
#     start_time = time.time() - paused_time  # 计算从暂停时的起始时间
#     timer_running = True
#     update_timer()  # 启动计时器
#     b_start.config(state=tk.DISABLED)
#     b_pause.config(state=tk.NORMAL)
#     b_end.config(state=tk.NORMAL)
#
# def on_pause():
#     global timer_running, paused_time
#     timer_running = False
#     paused_time = time.time() - start_time  # 记录暂停时的时间
#     b_pause.config(state=tk.DISABLED)
#     b_resume.config(state=tk.NORMAL)
#
# def on_resume():
#     global timer_running, start_time
#     start_time = time.time() - paused_time  # 恢复计时
#     timer_running = True
#     update_timer()  # 启动计时器
#     b_resume.config(state=tk.DISABLED)
#     b_pause.config(state=tk.NORMAL)
#
# def on_end():
#     reset_timer()  # 重置计时器
#     reset_buttons()  # 重置按钮状态
#
# def update_timer():
#     if timer_running:
#         elapsed_time = time.time() - start_time
#         minutes, seconds = divmod(elapsed_time, 60)
#         hours, minutes = divmod(minutes, 60)
#         time_str = f"{int(hours):02}:{int(minutes):02}:{int(seconds):02}"
#         label_time.config(text=time_str)
#         root.after(1000, update_timer)  # 每秒钟更新一次计时器


import tkinter as tk
import time
import os
from os.path import exists

import pyaudio
import wave
import threading
from datetime import datetime

# 设置录音参数
FORMAT = pyaudio.paInt16  # 16-bit depth
# FORMAT = pyaudio.paInt16  # 16-bit depth, use 8-bit (paInt8) for lower quality but smaller files, use 32-bit (paInt32) for higher quality but larger files
#
CHANNELS = 1  # Mono
# CHANNELS = 1  # Mono
# CHANNELS = 2 means stereo, larger files but better audio experience. If you need to keep multiple channels (e.g. music or ambient sound), use stereo.

RATE = 44100  # Sample rate
# RATE = 44100  # Sample rate. If too low (e.g. 22050 Hz or lower), audio will be distorted, especially high frequencies.
# # If too high (e.g. 96000 Hz or higher), better quality but much larger files, and the difference may not be obvious to the human ear, especially for normal speech.
CHUNK = 1024  # Audio block size per read
'''
This is the audio block size per read, i.e., the number of samples read from the audio stream each time.
Choosing the right CHUNK size is important:
Smaller CHUNK (e.g. 512 or 256) reduces latency but increases processing frequency and performance requirements.
Larger CHUNK (e.g. 2048 or 4096) reduces processing frequency and CPU load but may increase latency.
1024 is a commonly used value, balancing latency and performance.
'''

OUTPUT_FILENAME = f"{datetime.now().strftime('%Y-%m-%d %H-%M-%S')}.wav"  # Output file name

# Initialize PyAudio
p = pyaudio.PyAudio()

# Global variables
recording = False
paused = False
frames = []
start_time = 0
paused_time = 0
timer_running = False

# Create main window
root = tk.Tk()
root.title("DUAN_recording")

# Check and set window icon
icon_path = "../img/plane.ico"
if os.path.exists(icon_path):
    root.iconbitmap(icon_path)

# Set window properties
root.attributes('-alpha', 0.95)  # Set transparency
root.attributes('-topmost', 1)  # Set window always on top

# Get screen size
screen_width, screen_height = root.winfo_screenwidth(), root.winfo_screenheight()

# Calculate window size and position
window_width = min(300, screen_width * 4 // 5)  # 4/5
window_height = min(140, screen_height // 6)
x_position = (screen_width - window_width) // 2
y_position = min((screen_height - window_height) * 3 // 6, screen_height - window_height - 50)

root.geometry(f"{window_width}x{window_height}+{x_position}+{y_position}")
print(f"{window_width}x{window_height}+{x_position}+{y_position}")
root.config(bg='black')
root.resizable(False, False)
root.minsize(window_width, window_height)

# Timer update function
def update_timer():
    global timer_running, start_time,paused
    if timer_running and not paused:
        elapsed_time = time.time() - start_time
        minutes, seconds = divmod(elapsed_time, 60)
        hours, minutes = divmod(minutes, 60)
        time_str = f"{int(hours):02}:{int(minutes):02}:{int(seconds):02}"
        label_time.config(text=time_str)
    if timer_running:  # Continue callback regardless of pause (wait for next resume)
        root.after(1000, update_timer)  # Update timer every second

# Reset buttons
def reset_buttons():
    b_start.config(state=tk.NORMAL)
    b_pause.config(state=tk.DISABLED)
    b_resume.config(state=tk.DISABLED)
    b_end.config(state=tk.DISABLED)

# Reset timer
def reset_timer():
    global timer_running, start_time, paused_time
    timer_running = False
    start_time = 0
    paused_time = 0
    label_time.config(text="00:00:00")

# Start recording
def on_start():
    global recording, paused, frames, start_time, timer_running
    frames = []  # Clear recording buffer
    recording = True
    paused = False
    start_time = time.time() - paused_time
    timer_running = True
    update_timer()

    # Start recording stream
    def record():
        global paused
        stream = p.open(format=FORMAT,
                        channels=CHANNELS,
                        rate=RATE,
                        input=True,
                        frames_per_buffer=CHUNK)
        while recording:
            if not paused:
                data = stream.read(CHUNK)
                frames.append(data)
            time.sleep(0.01)  # Wait a bit to avoid high CPU usage

        stream.stop_stream()
        stream.close()

    threading.Thread(target=record, daemon=True).start()

    b_start.config(state=tk.DISABLED)
    b_pause.config(state=tk.NORMAL)
    b_end.config(state=tk.NORMAL)

# Pause recording
def on_pause():
    global paused, paused_time
    paused = True
    paused_time = time.time() - start_time  # ✅ Record elapsed time before pause
    print("Recording paused...")
    b_pause.config(state=tk.DISABLED)
    b_resume.config(state=tk.NORMAL)

# Resume recording
def on_resume():
    global paused, start_time
    paused = False
    start_time = time.time() - paused_time  # ✅ Reset start point for resume
    print("Recording resumed...")
    b_resume.config(state=tk.DISABLED)
    b_pause.config(state=tk.NORMAL)


# End recording
def on_end():
    global recording
    recording = False
    save_recording()
    reset_timer()  # Reset timer
    reset_buttons()  # Reset button status

# Save recording
def save_recording():
    os.makedirs(name="./video", exist_ok=True)
    filename = f"./video/{datetime.now().strftime('%Y-%m-%d %H-%M-%S')}.wav"
    with wave.open(filename, 'wb') as wf:
        wf.setnchannels(CHANNELS)
        wf.setsampwidth(p.get_sample_size(FORMAT))
        wf.setframerate(RATE)
        wf.writeframes(b''.join(frames))
    print(f"Recording saved as {filename}")

# UI components
fun_frame = tk.Frame(root, bg='#7FFFAA')
fun_frame.place(x=5, y=5, width=135, height=120)

label_time = tk.Label(fun_frame, bg='white', fg='black', text="00:00:00", font=("Times New Roman", 20))
label_time.place(x=5, y=25, width=125, height=60)

frame_setting = tk.Frame(root, bg='#7FFFAA')
frame_setting.place(x=145, y=5, width=150, height=120)

b_start = tk.Button(frame_setting, text='Start', command=on_start)
b_start.place(x=10, y=10, width=60, height=45)

b_pause = tk.Button(frame_setting, text='Pause', command=on_pause, state=tk.DISABLED)
b_pause.place(x=80, y=10, width=60, height=45)

b_resume = tk.Button(frame_setting, text='Resume', command=on_resume, state=tk.DISABLED)
b_resume.place(x=10, y=65, width=60, height=50)

b_end = tk.Button(frame_setting, text='End', command=on_end, state=tk.DISABLED)
b_end.place(x=80, y=65, width=60, height=50)

root.mainloop()

