##############################
''''

Faster Whisper: Also does not fully support real-time streaming input, but its acceleration performance can significantly reduce latency in batch processing. If you split the audio into small segments and process them step by step, Faster Whisper is more suitable for low-latency tasks than the original Whisper.

Faster Whisper can recognize many languages including but not limited to English, French, Spanish, German, Chinese, Japanese, Russian, and can handle various accents and dialects.
English accents: Whether it's British English, American English, or Indian accents, Whisper and Faster Whisper have strong adaptability.
Non-English accents: Whisper and Faster Whisper also have good recognition for other languages (such as French, German, etc.), and can handle a certain degree of local dialects.

Whisper speed
Model   Speed experience    Recommended scenario
tiny / base    Almost real-time or near real-time    Small programs, real-time subtitles
small          Slightly slower, but still acceptable  Normal applications
medium / large Very slow, not suitable for real-time  Offline transcription, large data processing
'''

# https://github.com/SYSTRAN/faster-whisper

import os
os.environ["HF_HUB_DISABLE_SYMLINKS_WARNING"] = "1"
from faster_whisper import  WhisperModel
import time
import torch

# print(torch.cuda.is_available())  # True means CUDA is available
# print(torch.cuda.device_count())  # Number of GPUs
# print(torch.cuda.get_device_name(0))  # GPU Name
#
#
# exit()

def kyle_faster_whisper_1(model_type: str= "tiny",
                          abs_path:str="",
                          beam_size: int=5,
                          # language: str=None,
                          task: str="transcribe",
                          compute_type: str="float16",
                          device: str="cuda" if torch.cuda.is_available() else "cpu"
                          ) -> tuple[list[str], list[str]]:
    
    # model_type: ["tiny", "base", "small", "medium", "large-v2", "large-v3"]

    if not abs_path:
        raise ValueError("abs_path is required!")
    if not os.path.isfile(abs_path):
        raise FileNotFoundError(f"The file at {abs_path} was not found!")

    # Validating model_type
    # valid_model_types = ["tiny", "base", "small", "medium", "large-v2", "large-v3"]
    # if model_type not in valid_model_types:
    #     raise ValueError(f"Invalid model_type: {model_type}. \nValid options are: {valid_model_types}")

    # validating device
    if (torch.cuda.is_available()) and (device == "cuda") and (compute_type in ["int8_float16","float16","float32","int8"]):
        model = WhisperModel(model_type, device="cuda", compute_type=compute_type) # CUDA support: int8, float16, float32, int8_float16

    elif (device == "cpu") and (compute_type in ["float32","int8"]):
        model = WhisperModel(model_type, device="cpu", compute_type=compute_type)   # CPU support: int8, float32

    elif (device == "cpu") and (compute_type in ["float16","int8_float16"]):
        print(r"CPU: int8_float16 and float16 not supported, int8 will be used")
        model = WhisperModel(model_type, device="cpu", compute_type="int8")


    segments, _ = model.transcribe(audio=abs_path,
                                   beam_size=beam_size,
                                   task=task, # transcribe OR translate
                                   # vad_filter=True,
                                   )
    # task: Default is transcribe, i.e., output transcription in the same language. Can set to translate to translate from one language to English.
    # vad_filter: Enable Voice Activity Detection (VAD) to filter out non-speech parts. This step uses the Silero VAD model (GitHub).
    # log_progress: Whether to show progress bar or not.
    #
#
# '''
# Parameter translation:
#
#     audio: Input file path (or file-like object), or audio waveform.
#
#     language: Language in the audio, use language code (such as "en" or "fr"). If not set, detection will be performed in the first 30 seconds of audio.
#
#     task: Task to execute (transcribe or translate).
#
#     log_progress: Whether to show progress bar.
#
#     beam_size: Beam size for decoding.
#
#     best_of: Number of candidates used for non-zero temperature sampling.
#
#     patience: Patience factor for beam search.
#
#     length_penalty: Exponential length penalty constant.
#
#     repetition_penalty: Apply penalty to previously generated token scores (set > 1 to penalize).
#
#     no_repeat_ngram_size: Prevent n-gram repetition, set to 0 to disable.
#
#     temperature: Temperature for sampling, can be a tuple of temperatures, if failed, use compression_ratio_threshold or log_prob_threshold in order.
#
#     compression_ratio_threshold: If gzip compression ratio exceeds this value, it is considered a failure.
#
#     log_prob_threshold: If the average log probability of sampled tokens is lower than this value, it is considered a failure.
#
#     no_speech_threshold: If the probability of no speech is higher than this value and the average log probability is lower than log_prob_threshold, the segment is considered silent.
#
#     condition_on_previous_text: If True, the model's previous output will be used as a prompt for the next window; disabling this option may cause inconsistency between windows, but may reduce the model getting stuck in failure loops (such as repeated loops or timestamp desynchronization).
#
#     prompt_reset_on_temperature: If the temperature is higher than this value, reset the prompt, only effective when condition_on_previous_text is True.
#
#     initial_prompt: Optional text string or token ID iterator, used as the prompt for the first window.
#
#     prefix: Optional text prefix, used as the starting text for the first window.
#
#     suppress_blank: Suppress blank output at the start of sampling.
#
#     suppress_tokens: List of token IDs to suppress, -1 will suppress the default symbols defined by tokenizer.non_speech_tokens().
#
#     without_timestamps: Only sample text tokens.
#
#     max_initial_timestamp: The initial timestamp cannot be later than this value.
#
#     word_timestamps: Use cross-attention mode and dynamic time warping (DTW) to extract word-level timestamps, and include individual word timestamps in each segment.
#
#     prepend_punctuations: If word_timestamps is True, merge these punctuation marks with the next word.
#
#     append_punctuations: If word_timestamps is True, merge these punctuation marks with the previous word.
#
#     multilingual: Perform language detection for each segment.
#
#     vad_filter: Enable voice activity detection (VAD) to filter out non-speech parts. This step uses the Silero VAD model (GitHub).
#
#     vad_parameters: Silero VAD parameter dictionary or VadOptions class (see available parameters and defaults in VadOptions class).
#
#     max_new_tokens: Maximum number of new tokens generated per segment, if not set, use default max_length.
#
#     chunk_length: Length of audio segments. If set, overrides the default chunk_length of FeatureExtractor.
#
#     clip_timestamps: Comma-separated timestamps start,end,start,end,... (seconds), specify the audio segments to process. The last end timestamp defaults to the end of the file. When using clip_timestamps, vad_filter is ignored.
#
#     hallucination_silence_threshold: When word_timestamps is True, if possible hallucination is detected and the silence time exceeds this threshold (seconds), skip the silent segment.
#
#     hotwords: Hotwords or prompt phrases provided to the model. If prefix is not None, this parameter is invalid.
#
#     language_detection_threshold: If the maximum probability of the language token is higher than this value, language detection is considered successful.
#
#     language_detection_segments: Number of segments used for language detection.
#
# '''


    ############### info is class ##############
    # language + language_probability: Automatic language detection result
    # duration + duration_after_vad: Total audio duration & valid speech duration
    # all_language_probs: Multilingual recognition probability distribution
    # transcription_options: Parameters controlling transcription (model, translation, etc.)
    # vad_options: Parameters controlling voice activity detection behavior

    context1 = []
    context2 = []

    for segment in segments:
        # print(f"\n\n[{segment.start:.2f}s -> {segment.end:.2f}s] {segment.text}")
        context1.append(segment.text)
        context2.append(f"[{segment.start:.2f}s -> {segment.end:.2f}s] {segment.text}")
    return context1, context2







def kyle_faster_whisper_0(model_type="tiny", abs_path=""):
    # Check if the file path exists
    if not abs_path:
        raise ValueError("abs_path is required!")
    if not os.path.isfile(abs_path):
        raise FileNotFoundError(f"The file at {abs_path} was not found!")

    # Validating model_type
    valid_model_types = ["tiny", "base", "small", "medium", "large-v2", "large-v3"]
    if model_type not in valid_model_types:
        raise ValueError(f"Invalid model_type. Valid options are: {', '.join(valid_model_types)}")

    # Measure model loading time
    t1 = time.time()
    if torch.cuda.is_available() :
        print("torch.cuda.is_available(): ",torch.cuda.is_available())  # True means CUDA is available
        # print("torch.cuda.device_count(): ", torch.cuda.device_count())  # Number of GPUs
        # print("torch.cuda.get_device_name(0): ", torch.cuda.get_device_name(0))  # GPU Name
        model = WhisperModel(model_type, device="cuda", compute_type="float32")
        model = WhisperModel(model_type, device="cuda", compute_type="float16")
        model = WhisperModel(model_type, device="cuda", compute_type="int8_float16")
        model = WhisperModel(model_type, device="cuda", compute_type="int8")


    elif not torch.cuda.is_available() :
        model = WhisperModel(model_type, device="cpu", compute_type="float32")
        # model = WhisperModel(model_type, device="cpu", compute_type="float16")  # not support
        # modelc816 = WhisperModel(model_type, device="cpu", compute_type="int8_float16") # not support
        # model = WhisperModel(model_type, device="cpu", compute_type="int8")

    t2 = time.time()
    print(f"\nModel loading time: {t2 - t1:.6f} seconds")

    # Measure transcription time
    t3 = time.time()
    segments, info = model.transcribe(audio=abs_path,
                                      beam_size=5,
                                     # language="None",
                                      task="translate",  # translate   transcribe
                                      vad_filter=True,
                                      # log_progress=True
                                      )
    # task: 默认是transcribe，即输出同语言转写，，，，可设置translate，从xxxx 翻译为 英文
    # task: Task to execute (transcribe or translate).
    # vad_filter：启用语音活动检测（VAD），以过滤无语音部分。该步骤使用 Silero VAD 模型（GitHub）。
    # log_progress: whether to show progress bar or not.
    #
#
# '''
# Parameter translation:
#
#     audio: Input file path (or file-like object), or audio waveform.
#
#     language: Language in the audio, use language code (such as "en" or "fr"). If not set, detection will be performed in the first 30 seconds of audio.
#
#     task: Task to execute (transcribe or translate).
#
#     log_progress: Whether to show progress bar.
#
#     beam_size: Beam size for decoding.
#
#     best_of: Number of candidates used for non-zero temperature sampling.
#
#     patience: Patience factor for beam search.
#
#     length_penalty: Exponential length penalty constant.
#
#     repetition_penalty: Apply penalty to previously generated token scores (set > 1 to penalize).
#
#     no_repeat_ngram_size: Prevent n-gram repetition, set to 0 to disable.
#
#     temperature: Temperature for sampling, can be a tuple of temperatures, if failed, use compression_ratio_threshold or log_prob_threshold in order.
#
#     compression_ratio_threshold: If gzip compression ratio exceeds this value, it is considered a failure.
#
#     log_prob_threshold: If the average log probability of sampled tokens is lower than this value, it is considered a failure.
#
#     no_speech_threshold: If the probability of no speech is higher than this value and the average log probability is lower than log_prob_threshold, the segment is considered silent.
#
#     condition_on_previous_text: If True, the model's previous output will be used as a prompt for the next window; disabling this option may cause inconsistency between windows, but may reduce the model getting stuck in failure loops (such as repeated loops or timestamp desynchronization).
#
#     prompt_reset_on_temperature: If the temperature is higher than this value, reset the prompt, only effective when condition_on_previous_text is True.
#
#     initial_prompt: Optional text string or token ID iterator, used as the prompt for the first window.
#
#     prefix: Optional text prefix, used as the starting text for the first window.
#
#     suppress_blank: Suppress blank output at the start of sampling.
#
#     suppress_tokens: List of token IDs to suppress, -1 will suppress the default symbols defined by tokenizer.non_speech_tokens().
#
#     without_timestamps: Only sample text tokens.
#
#     max_initial_timestamp: The initial timestamp cannot be later than this value.
#
#     word_timestamps: Use cross-attention mode and dynamic time warping (DTW) to extract word-level timestamps, and include individual word timestamps in each segment.
#
#     prepend_punctuations: If word_timestamps is True, merge these punctuation marks with the next word.
#
#     append_punctuations: If word_timestamps is True, merge these punctuation marks with the previous word.
#
#     multilingual: Perform language detection for each segment.
#
#     vad_filter: Enable voice activity detection (VAD) to filter out non-speech parts. This step uses the Silero VAD model (GitHub).
#
#     vad_parameters: Silero VAD parameter dictionary or VadOptions class (see available parameters and defaults in VadOptions class).
#
#     max_new_tokens: Maximum number of new tokens generated per segment, if not set, use default max_length.
#
#     chunk_length: Length of audio segments. If set, overrides the default chunk_length of FeatureExtractor.
#
#     clip_timestamps: Comma-separated timestamps start,end,start,end,... (seconds), specify the audio segments to process. The last end timestamp defaults to the end of the file. When using clip_timestamps, vad_filter is ignored.
#
#     hallucination_silence_threshold: When word_timestamps is True, if possible hallucination is detected and the silence time exceeds this threshold (seconds), skip the silent segment.
#
#     hotwords: Hotwords or prompt phrases provided to the model. If prefix is not None, this parameter is invalid.
#
#     language_detection_threshold: If the maximum probability of the language token is higher than this value, language detection is considered successful.
#
#     language_detection_segments: Number of segments used for language detection.
#
# '''


    ############### info is class ##############
    # language + language_probability: Automatic language detection result
    # duration + duration_after_vad: Total audio duration & valid speech duration
    # all_language_probs: Multilingual recognition probability distribution
    # transcription_options: Parameters controlling transcription (model, translation, etc.)
    # vad_options: Parameters controlling voice activity detection behavior

    t4 = time.time()
    # print(f"\n{segments}")
    # print(f"\n{info.all_language_probs}")
    # print(f"\n{info.transcription_options}")
    # print(f"\n{info.vad_options}")
    #
    #
    print(f"\n\nModel transcribe time: {t4 - t3:.6f} seconds")
    # print(f"\n\nDetected language '{info.language}' with probability {info.language_probability:.2f}")

    # Collect transcribed text and print segments
    context = []
    for segment in segments:
        print(f"\n\n[{segment.start:.2f}s -> {segment.end:.2f}s] {segment.text}")
        context.append(segment.text)
    print("\n\nContext:", context)
    return context





if __name__ == "__main__":

    try:
        a1,a2 = kyle_faster_whisper_1(model_type="large",
                                  abs_path="./video/2.mp3",
                                  task="transcribe",
                                  compute_type="int8",
                                  device="cuda",)
        print(a1)
        print(a2)

    except Exception as e:
        print(f"Error: {e}")




    # Example usage
    # try:
    #     result = kyle_faster_whisper_0(model_type="tiny", abs_path="./audio_recording/61-70970-0000.flac")
    # except Exception as e:
    #     print(f"Error: {e}")