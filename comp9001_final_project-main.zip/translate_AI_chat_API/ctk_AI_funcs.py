import os

from markdown import markdown
from transfer_md_textfont.webframe_css import get_html_style, get_scroll_fix_css
import customtkinter as ctk

def create_toplevel_with_icon(top, icon_path):
    icon_abs = os.path.abspath(icon_path)
    top.iconbitmap(icon_abs)
    
    # Automatically listen for windows to be restored or updated before setting icons (only one binding)
    def reapply_icon(event=None):
        try:
            top.iconbitmap(icon_abs)
        except:
            pass

    # Bind events for window display, activation, etc.
    top.bind("<Map>", reapply_icon)         # Windows appear
    top.bind("<Visibility>", reapply_icon)  # Window becomes visible Window becomes visible
    top.bind("<FocusIn>", reapply_icon)     # Get Focus
    top.update()
    return top



def text_or_mdtext1(root, output_frame, output_frame2,var2):

        var2.set(0)  # Cancel the second checkbox
        output_frame.grid_remove()
        output_frame2.grid(row=0, rowspan=2, column=0, columnspan=8, sticky="nsew", padx=10, pady=10)
        root.update()

def text_or_mdtext2(root, output_frame, output_frame2,var1):

        var1.set(0)  # Cancel the second checkbox
        output_frame2.grid_remove()
        output_frame.grid()
        root.update()




def get_text_from_user(root,input_text):
    usr_input = input_text.get("1.0", "end").strip()
    input_text.delete("1.0", "end")
    root.update()  # Without refresh, the display will be delayed 
    # "1.0"` means that the text is extracted from the first line of the text, from the 0th column position (lines and columns are counted from 1 and 0).
    # "end"` means extract to the end of the text (including the line break `\n` at the end, if any).
    if usr_input !="":
        return usr_input
    else:
        return ""


def convert_markdown(root, output_html_frame,outputframe2, ai_answer, index: int = 0, ):
    if index == 1:
        t1 = '''
#The free version provides:
##gpt-4o, gpt-4.1 for 5 times a day,
##deepseek-r1, deepseek-v3 for 30 times a day,
##gpt-4o-mini, gpt-3.5-turbo, gpt-4.1-mini, gpt-4.1-nano for 200 times a day.
'''
        outputframe2.insert("0.0",t1)
        root.update()
        html = markdown(t1, extensions=["fenced_code", "tables", "codehilite", "nl2br"])
        style = get_html_style(scale=1) + get_scroll_fix_css()
        styled_html = style + html
        output_html_frame.load_html(styled_html)
        root.update()
    else:
        outputframe2.delete("0.0", "end")
        markdown_text = ai_answer
        outputframe2.insert("0.0", ai_answer)
        root.update()
        if markdown_text:
            html = markdown(markdown_text, extensions=["fenced_code", "tables", "codehilite", "nl2br"])
            style = get_html_style(scale=1.5) + get_scroll_fix_css()
            styled_html = style + html
            output_html_frame.load_html(styled_html)
        root.update()







