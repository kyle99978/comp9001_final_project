########################################################################################################
# Improvements Effect
# pre Auto line feed + horizontal scrolling compatibility Preserves scrollbars while allowing line feeds in narrower windows.
# Multi-level li indentation makes nested structures more visible.
# table default style enhancement add border + light grey background in table header, better look.
# Separate code and pre settings to better match Markdown semantic differences.

#  Day mode: black text on white background
#  Night mode: white text on dark grey background
#  Automatically follow CustomTkinter current theme (ctk.get_appearance_mode())
#  Styles include headings, paragraphs, lists, code blocks, tables, links
#  Easy to use (only one function call)

# from markdown import markdown
#
# # Get the CSS styles corresponding to the current theme.
# style = get_html_style()
#
# # Convert Markdown content
# html = markdown(markdown_text, extensions=["fenced_code", "tables"])
#
# # Stitch the styles and display them
# output_html_frame.load_html(style + html)



import customtkinter as ctk

def get_scroll_fix_css():
    return """
    <style>
        pre, code, table {
            display: block;
            overflow-x: auto;
            white-space: pre-wrap;
            word-wrap: break-word;
        }
        body {
            overflow-x: auto;
        }
    </style>
    """


def get_html_style(mode="System", scale=1.0) -> str:
    """
    Generate adaptive dark/light theme + HTML style supporting visual scaling
    Parameters:
        mode: "Light" | "Dark" | "System"
        scale: Visual magnification (default 1.0)
    """
    if mode == "System":
        mode = ctk.get_appearance_mode()

    # Color scheme
    if mode == "Dark":
        background = "#1e1e1e"
        foreground = "#eeeeee"
        code_bg = "#2d2d2d"
        table_border = "#444"
        table_header = "#333"
        link_color = "#4ea1ff"
    else:
        background = "#ffffff"
        foreground = "#000000"
        code_bg = "#f4f4f4"
        table_border = "#ccc"
        table_header = "#f0f0f0"
        link_color = "blue"

    # Font size base
    base = 16 * scale
    h1 = int(base * 2.0)
    h2 = int(base * 1.6)
    h3 = int(base * 1.4)
    h4 = int(base * 1.2)
    h5 = int(base * 1.0)
    h6 = int(base * 0.9)
    code_font = int(base * 0.95)
    pre_font = int(base * 0.95)
    line_height = round(1.6 * scale, 2)
    pad = int(12 * scale)
    cell_pad = int(8 * scale)

    return f"""
<style> 
    body {{
        font-family: 'Segoe UI', 'Calibri', 'Helvetica', sans-serif;
        font-size: {base}px;
        color: {foreground};
        background-color: {background};
        line-height: {line_height};
        padding: {pad}px;
    }}

    h1 {{ font-size: {h1}px; font-weight: bold; }}
    h2 {{ font-size: {h2}px; font-weight: bold; }}
    h3 {{ font-size: {h3}px; font-weight: bold; }}
    h4 {{ font-size: {h4}px; font-weight: bold; }}
    h5 {{ font-size: {h5}px; font-weight: bold; }}
    h6 {{ font-size: {h6}px; font-weight: bold; }}

    p, div {{ margin-bottom: {int(1.0 * scale)}em; }}

    code {{
        font-size: {code_font}px;
        font-family: 'Courier New', monospace;
        background-color: {code_bg};
        padding: 2px 5px;
        border-radius: 4px;
    }}

    pre {{
        font-size: {pre_font}px;
        font-family: 'Courier New', monospace;
        background-color: {code_bg};
        padding: {pad}px;
        border-radius: 5px;
        overflow-x: auto;
        white-space: pre-wrap;
        word-wrap: break-word;
    }}

    ul, ol {{
        padding-left: {24 * scale}px;
        margin-bottom: 1em;
    }}

    li {{
        margin: 4px 0;
    }}

    ul ul, ol ul, ul ol, ol ol {{
        margin-left: 20px;
    }}

    a {{
        color: {link_color};
        text-decoration: underline;
    }}

    table {{
        border-collapse: collapse;
        margin: 1em 0;
        width: 100%;
        overflow-x: auto;
       /* display: block;*/
    }}

    th, td {{
        border: 1px solid {table_border};
        padding: {cell_pad}px {cell_pad + 2}px;
        text-align: left;
        white-space: pre-line; /* ✅ Here to ensure <br> and line breaks are effective */
        word-break: break-word; /* ✅ Prevent long words from breaking the table */
    }}

    th {{
        background-color: {table_header};
    }}
</style>
"""
