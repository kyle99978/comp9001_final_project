import customtkinter as ctk
from markdown import markdown
from tkhtmlview import HTMLLabel  # Used to render content in HTML format
# from tkinterweb import HtmlFrame
import tkinterweb as TKweb

# tkinterweb and tkhtmlview difference:
# tkhtmlview: has built-in font style, no need to add css to beautify later, but can't be copied and edited.
# tkinterweb can be copied, but you need to customise the css.

from transfer_md_textfont.webframe_css import get_html_style, get_scroll_fix_css

# Initialising the CustomTkinter application
ctk.set_appearance_mode("System")  # Appearance: "System", "Dark", "Light"
ctk.set_default_color_theme("blue")  # Theme color: "blue", "dark-blue", "green"

# Creating the main window
root0 = ctk.CTk()
root0.withdraw()

root = ctk.CTkToplevel()
root.title("Markdown tool")
root.geometry("800x500")

root.grid_rowconfigure(0, weight=2)
root.grid_rowconfigure(1, weight=1)
root.grid_columnconfigure(0, weight=1)



# Above: HTML rendering window
output_frame = ctk.CTkFrame(root,corner_radius=10, fg_color="#999999")
output_frame.grid(row=0, column=0, columnspan=8,sticky="nsew", padx=10, pady=10)

# HTMLLabel
output_html_frame = HTMLLabel(output_frame, )

 
# Overflow behaviour is controlled by CSS by default, overflow-x: auto must be explicitly specified to have any effect.
# No horizontal scrollbar, internal mechanism, horizontal_scrollbar="auto" parameter is not implemented by HtmlFrame.

output_html_frame.pack(fill="both", expand=True, padx=10, pady=10)
# output_html_frame = TKweb.HtmlFrame(output_frame, messages_enabled=True,
#                                     vertical_scrollbar="auto",
 
# Overflow behaviour is controlled by CSS by default, overflow-x: auto must be explicitly specified to have any effect.
# No horizontal scrollbar, internal mechanism, horizontal_scrollbar="auto" parameter is not implemented by HtmlFrame.
#                                     )
# output_html_frame.pack(fill="both", expand=True, padx=10, pady=10)

def convert_markdown(index:str="test"):
    if index ==1:
        html = markdown("", extensions=["fenced_code", "tables", "codehilite", "nl2br"])
        # style = get_html_style(scale=2) + get_scroll_fix_css()
        # styled_html = style + html
        output_html_frame.set_html(html)
    else:
        markdown_text = input_text.get("1.0", "end").strip()

        if markdown_text:
            html = markdown(markdown_text, extensions=["fenced_code", "tables", "codehilite", "nl2br"])
            # style = get_html_style(scale=2) + get_scroll_fix_css()
            # styled_html = style + html
            output_html_frame.set_html(html)



# Below: Markdown input window
input_text = ctk.CTkTextbox(root, wrap="none",)
input_text.insert("1.0", "# input here\nlike, `Hello World`")
input_text.grid(row=1, column=0, columnspan=8, sticky="nsew", padx=10, pady=10)
convert_markdown(index="test")


def txt_or_md(choice):
    if choice == 1:
        var2.set(0)  # Cancel the second checkbox
    elif choice == 2:
        var1.set(0)  # Cancel the first checkbox

# Add two variables for checkbox
var1 = ctk.IntVar()
var2 = ctk.IntVar()

# Modify checkbox
convert_button1 = ctk.CTkCheckBox(root, text="text", variable=var1,
                                  command=lambda val=1: txt_or_md(val), width=50, height=30)
convert_button1.grid(row=3, column=1, padx=5, pady=10)

convert_button2 = ctk.CTkCheckBox(root, text="md text", variable=var2,
                                  command=lambda val=2: txt_or_md(val), width=50, height=30)
convert_button2.grid(row=3, column=2, padx=5, pady=10)




# Centre: changeover button
convert_button = ctk.CTkButton(root, text="save as", command=convert_markdown,width=80,height=30)
convert_button.grid(row=3, column=5, padx=10, pady=10)

# Centre: changeover button
convert_button = ctk.CTkButton(root, text="转换", command=convert_markdown,width=80,height=30)
convert_button.grid(row=3, column=6, padx=10, pady=10)

# Run the main programme loop
root.mainloop()
