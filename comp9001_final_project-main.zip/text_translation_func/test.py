import os
import time
import torch
from transformers import MarianMTModel, MarianTokenizer
from huggingface_hub import hf_hub_download
import traceback

# Disable HuggingFace Symbolic Link Warning
os.environ["HF_HUB_DISABLE_SYMLINKS_WARNING"] = "1"
os.environ["HF_HUB_DISABLE_SYMLINKS_WARNING"] = "true"

# 2D array defining language pairs, models, test text
# https://huggingface.co/models?sort=downloads&search=opus-mt
# Hugging Face is an open source collection of thousands of AI models, you can search, download, call, and upload your own AI models for free.
#
# Helsinki-NLP
# The most famous thing is the Opus-MT project (Opus Machine Translation) which is a collection of multilingual translation models.
# The Helsinki-NLP team trained thousands of language pairs with MarianMT (a very efficient open source translation framework) and then made it all free and open source, and it's uploaded on Hugging Face!
#
# team bg
# Main Research Interests Natural Language Processing (NLP), Machine Translation (MT), Multilingual Models
# Representative achievements Tatoeba translation models, Opus-MT series models.
# Uploaded a large number of their trained translation models on Hugging Face.
# Style Lightweight, open, strong multilingual support.
# A research team (NLP research group), affiliated with the University of Helsinki, Finland.
 




LANGUAGE_MODEL_MAPPING = [
    ["XX-英文", "xx-en", "Helsinki-NLP/opus-mt-mul-en", "白毛浮绿水，红掌拨清波"],

    # Chinese --> other languages
    ["中文-英文", "zh-en", "Helsinki-NLP/opus-mt-zh-en", "白毛浮绿水，红掌拨清波"],
    ["中文-日语", "zh-ja", "Helsinki-NLP/opus-mt-tc-big-zh-ja", "白毛浮绿水，红掌拨清波"],
    # ["中文-韩文", "zh-ko", "Helsinki-NLP/opus-mt-zh-ko", "白毛浮绿水，红掌拨清波"], # no
    # ["中文-俄文", "zh-ru", "Helsinki-NLP/opus-mt-zh-ru", "白毛浮绿水，红掌拨清波"], # no

    # English --> other languages
    ["英文-中文", "en-zh", "Helsinki-NLP/opus-mt-en-zh", "White fur floats on green water, red palms row through clear waves."],
    ["英文-日文", "en-jap", "Helsinki-NLP/opus-mt-en-jap", "The red petals float on the water."],
    ["英文-韩文", "en-ko", "Helsinki-NLP/opus-mt-tc-big-en-ko", "White fur floats on green water, red palms row through clear waves."],
    ["英文-俄文", "en-ru", "Helsinki-NLP/opus-mt-en-ru", "White fur floats on green water, red palms row through clear waves."],
    ["英文-法文", "en-fr", "Helsinki-NLP/opus-mt-en-fr", "The red petals float on the water."],

    # Japanese --> other languages
    ["日文-英文", "jap-en", "Helsinki-NLP/opus-mt-jap-en", "赤い花びらが水面に浮かぶ"],
    # ["日文-中文", "jap-zh", "Helsinki-NLP/opus-mt-tc-big-ja-zh", "赤い花びらが水面に浮かぶ"],
    # ["日文-韩文", "jap-ko", "Helsinki-NLP/opus-mt-jap-ko", "赤い花びらが水面に浮かぶ"],
    # ["日文-俄文", "jap-ru", "Helsinki-NLP/opus-mt-jap-ru", "赤い花びらが水面に浮かぶ"],

    # Korean to other languages
    ["韩文-英文", "ko-en", "Helsinki-NLP/opus-mt-ko-en", "흰 털은 녹색 물 위에 떠 있고, 붉은 손바닥은 맑은 물을 젓는다."],
    # ["韩文-中文", "ko-zh", "Helsinki-NLP/opus-mt-ko-zh", "흰 털은 녹색 물 위에 떠 있고, 붉은 손바닥은 맑은 물을 젓는다."],
    # ["韩文-日文", "ko-jap", "Helsinki-NLP/opus-mt-ko-jap", "흰 털은 녹색 물 위에 떠 있고, 붉은 손바닥은 맑은 물을 젓는다."],
    ["韩文-俄文", "ko-ru", "Helsinki-NLP/opus-mt-ko-ru", "흰 털은 녹색 물 위에 떠 있고, 붉은 손바닥은 맑은 물을 젓는다."],

    # French to other languages
    ["法文-英文", "fr-en", "Helsinki-NLP/opus-mt-fr-en", "Les pétales rouges flottent sur l'eau."],
    # ["法文-中文", "fr-zh", "Helsinki-NLP/opus-mt-fr-zh", "Les pétales rouges flottent sur l'eau."],
    # ["法文-日文", "fr-jap", "Helsinki-NLP/opus-mt-fr-jap", "Les pétales rouges flottent sur l'eau."],
    # ["法文-韩文", "fr-ko", "Helsinki-NLP/opus-mt-fr-ko", "Les pétales rouges flottent sur l'eau."],
    ["法文-俄文", "fr-ru", "Helsinki-NLP/opus-mt-fr-ru", "Les pétales rouges flottent sur l'eau."],

    # Russian to other languages
    ["俄文-英文", "ru-en", "Helsinki-NLP/opus-mt-ru-en",
     "Белый мех плывет по зеленой воде, красные ладони гребут по чистым волнам."],
    # ["俄文-中文", "ru-zh", "Helsinki-NLP/opus-mt-ru-zh", "Белый мех плывет по зеленой воде, красные ладони гребут по чистым волнам."],
    # ["俄文-日文", "ru-jap", "Helsinki-NLP/opus-mt-ru-jap", "Белый мех плывет по зеленой воде, красные ладони гребут по чистым волнам."],
    # ["俄文-韩文", "ru-ko", "Helsinki-NLP/opus-mt-ru-ko", "Белый мех плывет по зеленой воде, красные ладони гребут по чистым волнам。"],
    ["俄文-法文", "ru-fr", "Helsinki-NLP/opus-mt-ru-fr", "Белый мех плывет по зеленой воде, красные ладони гребут по чистым волнам。"]
]


def check_model_exists(model_name: str):
     
    # Check if the model exists in Hugging Face Hub
     :
        hf_hub_download(repo_id=model_name, filename="config.json", cache_dir="./model_cache")
        print(f"found 【{model_name}】 ✅")
        return True
    except Exception:
        print(f"No found【{model_name}】 ❌")
        return False


def translate_text_with_time(model_name: str, text: str,
                             device_setting: str = "auto",
                             precision_setting: str = "fp32"):
    """
    Translates using the specified translation task and input text, and counts stage times.

    Parameters.
    ------
    model_name : str
        Name of the model to use (Hugging Face model path).
    text : str
        Input text to be translated.
    device_setting : str, optional
        device_setting : str, optional, default is "auto" (supports "auto", "cpu", "cuda").
    precision_setting : str, optional
        Precision options, default "fp32" (supports "fp32", "fp16", "int8").

    Return value.
    -------
    tuple : (str, list)
        - str: the result of the translated text.
        - list: contains the time statistics of each stage [time spent on segmentation, time spent on translation, time spent on decoding].
    """ 


    # check device
    if device_setting == "auto":
        device = "cuda" if torch.cuda.is_available() else "cpu"
    else:
        device = device_setting
    print(f"current dev: {device}")

    # If CPU, force fp32
    if device == "cpu" and precision_setting != "fp32":
        print(f"⚠️ CPU does not support {precision_setting}, Auto to fp32。")
        precision_setting = "fp32"

    # Loading Models and Splitters
    print("Loading models, please wait...")
    model = None
    tokenizer = None
    try:
        if precision_setting == "fp16" and device == "cuda":
            model = MarianMTModel.from_pretrained(model_name, torch_dtype=torch.float16, cache_dir="./model_cache")
        else:
            model = MarianMTModel.from_pretrained(model_name, cache_dir="./model_cache")
        tokenizer = MarianTokenizer.from_pretrained(model_name, cache_dir="./model_cache")
    except Exception as e:
        print(f"Failed to load model ⚠️: {e}")
        return None, None

    model = model.to(device)

    # Timing of the translation phase
    inputs = tokenizer([text], return_tensors="pt", padding=True).to(device)

    # Translated text
    try:
        translated = model.generate(**inputs)
        translated_text = tokenizer.decode(translated[0], skip_special_tokens=True)
    except Exception as e:
        print(f"translation failure ⚠️: {e}")
        return None, None

    return translated_text, []


def test_translation_models(device_setting="auto", precision_setting="fp32"):
    """
    Tests all translation models to see if they are working properly and outputs their translation results and statistics.

    Parameter.
    ------
    device_setting : str, optional
        The device used for testing ("auto", "cpu", "cuda").
    precision_setting : str, optional
        Model precision ("fp32", "fp16", "int8").
    """

    print(f"Start testing all translation models...")
    print(f"dev: {device_setting}, Precision: {precision_setting}\n")

    for lang_pair in LANGUAGE_MODEL_MAPPING:
        lang, lang_id, model_name, sample_text = lang_pair
        print(f"Language pair task being validated: {lang} ({lang_id})")
        print(f"Model name: {model_name}")

        # Verify that the model exists
        if not check_model_exists(model_name):
            continue

        print(f"test: {sample_text}")

        try:
            translated_text, _ = translate_text_with_time(
                model_name=model_name,
                text=sample_text,
                device_setting=device_setting,
                precision_setting=precision_setting,
            )

            if translated_text:
                print(f"Successful translation ✅: {translated_text}\n")
            else:
                print(f"translation failure ❌\n")

        except Exception as e:
            print(f"Test failed, error cause: {e}\n")
            traceback.print_exc()

    print("All model testing complete！")


# Execute test scripts
if __name__ == "__main__":
    # Example settings
    device_setting = "auto"  # options: "cpu", "cuda", "auto"
    precision_setting = "fp32"  # options: "fp32", "fp16", "int8"

    # Call the test function
    test_translation_models(device_setting=device_setting, precision_setting=precision_setting)

    test_translation_models(device_setting="cpu", precision_setting="int8")
    test_translation_models(device_setting="cpu", precision_setting="fp16")
    test_translation_models(device_setting="cpu", precision_setting="fp32")

    test_translation_models(device_setting="cuda", precision_setting="int8")
    test_translation_models(device_setting="cuda", precision_setting="fp16")
    test_translation_models(device_setting="cuda", precision_setting="fp32")
